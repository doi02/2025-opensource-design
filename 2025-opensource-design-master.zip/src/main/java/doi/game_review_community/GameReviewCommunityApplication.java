package doi.game_review_community;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameReviewCommunityApplication {

	public static void main(String[] args) {
		SpringApplication.run(GameReviewCommunityApplication.class, args);
	}

}
