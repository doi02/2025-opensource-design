package doi.game_review_community.domain.game;

public enum Platform {
    PC,
    PLAYSTATION_5,
    PLAYSTATION_4,
    XBOX_SERIES_X,
    XBOX_ONE,
    NINTENDO_SWITCH,
    NINTENDO_SWITCH_2,
    NINTENDO_3DS,
    NINTENDO_WII_U,
    MOBILE
}