package doi.game_review_community.rawg.dto.developer;

import lombok.Data;

@Data
public class DeveloperWrapperDto {
    private DeveloperDetailDto developer;
}
