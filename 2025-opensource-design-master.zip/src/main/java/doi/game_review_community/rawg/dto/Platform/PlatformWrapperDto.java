package doi.game_review_community.rawg.dto.Platform;

import lombok.Data;

@Data
public class PlatformWrapperDto {
    private PlatformDetailDto platform;
}
