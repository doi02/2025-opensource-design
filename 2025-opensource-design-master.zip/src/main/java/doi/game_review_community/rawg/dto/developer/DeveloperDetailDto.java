package doi.game_review_community.rawg.dto.developer;

import lombok.Data;

@Data
public class DeveloperDetailDto {
    private String name;
}
