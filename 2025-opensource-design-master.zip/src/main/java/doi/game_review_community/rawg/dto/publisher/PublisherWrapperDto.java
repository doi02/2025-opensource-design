// 7. PublisherWrapperDto.java
package doi.game_review_community.rawg.dto.publisher;

import lombok.Data;

@Data
public class PublisherWrapperDto {
    private PublisherDetailDto publisher;
}
