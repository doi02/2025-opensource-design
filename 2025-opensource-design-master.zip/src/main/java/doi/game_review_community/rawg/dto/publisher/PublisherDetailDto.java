// 8. PublisherDetailDto.java
package doi.game_review_community.rawg.dto.publisher;

import lombok.Data;

@Data
public class PublisherDetailDto {
    private String name;
}
