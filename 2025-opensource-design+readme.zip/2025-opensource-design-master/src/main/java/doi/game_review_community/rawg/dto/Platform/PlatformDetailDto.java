package doi.game_review_community.rawg.dto.Platform;

import lombok.Data;

@Data
public class PlatformDetailDto {
    private String name;
}
