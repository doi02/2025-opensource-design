실행하는 방법입니다.

1.ide는 Intellij를 사용합니다.
2.의존이 설치될 때 까지 기다립니다.
3.의존이 모두 설치가되었으면
4.src/main/java/doi/game_review_community에 있는 GameReviewCommunityApplication을 실행시킵니다.
5. 실행이 되면 Crome에서 http://localhost:8080/에 접속합니다.